package com.example.myapplication;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class Tutor_class_reg extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tutor_class_reg);

        Button reg_btn = (Button) findViewById(R.id.tutor_class_reg_yes);
        reg_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDialog1();
            }
        });

        Button can_btn = (Button) findViewById(R.id.tutor_class_reg_cancel);
        can_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDialog2();
            }
        });
    }

    void showDialog1() {
        AlertDialog.Builder msg = new AlertDialog.Builder(Tutor_class_reg.this)
                .setMessage("수업 등록을 신청 하시겠습니까?")
                .setNegativeButton(Html.fromHtml("<font color='#0'>예</font>"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // 등록 완료 팝업.
                        Toast.makeText(Tutor_class_reg.this, "수업 등록신청이 완료되었습니다.", Toast.LENGTH_SHORT).show();

                        finish();
                    }
                })
                .setPositiveButton(Html.fromHtml("<font color='#0'>아니요</font>"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                    }
                });

        AlertDialog msgDlg = msg.create();

        msgDlg.show();
    }

    void showDialog2() {
        AlertDialog.Builder msg = new AlertDialog.Builder(Tutor_class_reg.this)
                .setMessage("수업 등록 신청을 취소 하시겠습니까?\n(취소시, 내용은 저장되지 않습니다.)")
                .setNegativeButton(Html.fromHtml("<font color='#0'>예</font>"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // 등록 완료 팝업.
                        Toast.makeText(Tutor_class_reg.this, "수업 등록신청이 취소되었습니다.", Toast.LENGTH_SHORT).show();

                        finish();
                    }
                })
                .setPositiveButton(Html.fromHtml("<font color='#0'>아니요</font>"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                    }
                });

        AlertDialog msgDlg = msg.create();

        msgDlg.show();
    }
}
