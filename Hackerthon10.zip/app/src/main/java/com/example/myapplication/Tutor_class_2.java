package com.example.myapplication;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class Tutor_class_2 extends AppCompatActivity {

    private TextView num;
    private int count = 0;
    private String st = "1";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tutor_class_2);


        Button reg_btn = (Button) findViewById(R.id.tutor_class_2_reg_btn);
        num = findViewById(R.id.num1);

        SharedPreferences sharedPreferences3 = getSharedPreferences(st, 0);
        int value = sharedPreferences3.getInt("c3", 0);
        count = value;
        num.setText(String.valueOf(count));

        reg_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDialog();
            }
        });
    }

    void showDialog() {
        AlertDialog.Builder msg = new AlertDialog.Builder(Tutor_class_2.this)
                .setMessage("수업 등록 하시겠습니까?")
                .setNegativeButton(Html.fromHtml("<font color='#0'>예</font>"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // 등록 완료 팝업.
                        Toast.makeText(Tutor_class_2.this, "수업 등록이 완료되었습니다.", Toast.LENGTH_SHORT).show();
                        count++;
                        num.setText(String.valueOf(count));
                        // ++
                        finish();

                    }
                })
                .setPositiveButton(Html.fromHtml("<font color='#0'>아니요</font>"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(Tutor_class_2.this, "수업 등록이 취소되었습니다.", Toast.LENGTH_SHORT).show();

                        finish();
                    }
                });

        AlertDialog msgDlg = msg.create();

        msgDlg.show();
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();


        SharedPreferences sharedPreferences3 = getSharedPreferences(st, 0);
        SharedPreferences.Editor editor0 = sharedPreferences3.edit();
        int value = count;
        editor0.putInt("c3",value);
        editor0.commit();

        //버튼 boolean 정보 저장
    }
}