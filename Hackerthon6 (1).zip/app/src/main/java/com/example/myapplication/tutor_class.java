package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class tutor_class extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tutor_class);

        Button btn1 = (Button) findViewById(R.id.tutor_btn1);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Tutor_class_0.class);
                startActivity(intent);
            }
        });

        Button btn2 = (Button) findViewById(R.id.tutor_btn2);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Tutor_class_1.class);
                startActivity(intent);
            }
        });

        Button btn3 = (Button) findViewById(R.id.tutor_btn3);
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Tutor_class_2.class);
                startActivity(intent);
            }
        });

        Button btn4 = (Button) findViewById(R.id.tutor_reg);
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Tutor_class_reg.class);
                startActivity(intent);
            }
        });
    }
}
