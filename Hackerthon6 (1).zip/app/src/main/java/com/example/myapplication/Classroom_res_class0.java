package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.google.android.material.chip.Chip;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Classroom_res_class0 extends AppCompatActivity {

    private TextView classroom_name;//강의실 이름
    private TextView text0;
    private TextView text1;
    private TextView text2;
    private TextView text3;
    private int count;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.classroom_res_class0);
        classroom_name = findViewById(R.id.classroom_name);
        Intent intent = getIntent();
        String name = intent.getStringExtra("classroom_name");
        classroom_name.setText(name);
        //강의실 이름 가져와 붙여넣기

        Chip classroom_res_class0_chip1 = (Chip) findViewById(R.id.time1);
        classroom_res_class0_chip1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Classroom_res_class0_table1.class);

                startActivity(intent);
            }
        });

        Chip classroom_res_class0_chip2 = (Chip) findViewById(R.id.time2);
        classroom_res_class0_chip2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Classroom_res_class0_table2.class);

                startActivity(intent);
            }
        });

        Chip classroom_res_class0_chip3 = (Chip) findViewById(R.id.time3);
        classroom_res_class0_chip3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Classroom_res_class0_table3.class);

                startActivity(intent);
            }
        });

        Chip classroom_res_class0_chip4 = (Chip) findViewById(R.id.time4);
        classroom_res_class0_chip4.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Classroom_res_class0_table4.class);

                startActivity(intent);
            }
        });

    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){//classtable에서 보내는 intent받기
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK) {
            String str = data.getStringExtra("cnt");
            text0.setText(str);
        }
    }
}
