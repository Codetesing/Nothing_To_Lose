package com.example.myapplication;

import android.content.DialogInterface;
import android.graphics.Color;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class Classroom_res_class0_table1 extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.classroom_res_class0_table0);

        Button btn0 = (Button) findViewById(R.id.room0_0_btn0);
        btn0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDialog(btn0);
            }
        });

        Button btn1 = (Button) findViewById(R.id.room0_0_btn1);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDialog(btn1);
            }
        });

        Button btn2 = (Button) findViewById(R.id.room0_0_btn2);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDialog(btn2);
            }
        });

        Button btn3 = (Button) findViewById(R.id.room0_0_btn3);
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDialog(btn3);
            }
        });
    }

    void showDialog(Button btn){
        AlertDialog.Builder msg = new AlertDialog.Builder(Classroom_res_class0_table1.this)
                .setMessage("자리 사용 등록 하시겠습니까?")
                .setPositiveButton(Html.fromHtml("<font color='#0'>아니요</font>"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(Classroom_res_class0_table1.this, "자리 사용 등록이 취소되었습니다.", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton(Html.fromHtml("<font color='#0'>예</font>"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // 등록 완료 팝업.
                        Toast.makeText(Classroom_res_class0_table1.this, "자리 사용 등록이 완료되었습니다.", Toast.LENGTH_SHORT).show();
                        btn.setBackgroundColor(Color.RED);
                    }
                });
        AlertDialog msgDlg = msg.create();
        msgDlg.show();
    }
}
