package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.google.android.material.chip.Chip;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Classroom_res_class1 extends AppCompatActivity {

    private TextView classroom_name;//강의실 이름

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.classroom_res_class1);
        classroom_name = findViewById(R.id.classroom_name);
        Intent intent = getIntent();
        String name = intent.getStringExtra("classroom_name");
        classroom_name.setText(name);
        //강의실 이름 가져와 붙여넣기

        Chip classroom_res_class1_chip1 = (Chip) findViewById(R.id.time1);
        classroom_res_class1_chip1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Classroom_res_class1_table1.class);

                startActivity(intent);
            }
        });

        Chip classroom_res_class1_chip2 = (Chip) findViewById(R.id.time2);
        classroom_res_class1_chip2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Classroom_res_class1_table2.class);

                startActivity(intent);
            }
        });

        Chip classroom_res_class1_chip3 = (Chip) findViewById(R.id.time3);
        classroom_res_class1_chip3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Classroom_res_class1_table3.class);

                startActivity(intent);
            }
        });

        Chip classroom_res_class1_chip4 = (Chip) findViewById(R.id.time4);
        classroom_res_class1_chip4.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Classroom_res_class1_table4.class);

                startActivity(intent);
            }
        });

    }
}