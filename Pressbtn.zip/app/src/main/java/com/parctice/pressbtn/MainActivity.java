package com.parctice.pressbtn;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Button btn;
    private int count; // 신청한 팀 수
    private TextView cnt; //0/4
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        count = 0;
        btn = findViewById(R.id.btn);
        cnt = findViewById(R.id.cnt);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDialog();
            }
        });
    }
    void showDialog(){
        AlertDialog.Builder msg = new AlertDialog.Builder(MainActivity.this)
                .setMessage("자리 사용 등록 하시겠습니까?")
                .setPositiveButton(Html.fromHtml("<font color='#0'>아니요</font>"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(MainActivity.this, "자리 사용 등록이 취소되었습니다.", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton(Html.fromHtml("<font color='#0'>예</font>"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // 등록 완료 팝업.
                        Toast.makeText(MainActivity.this, "자리 사용 등록이 완료되었습니다.", Toast.LENGTH_SHORT).show();
                        count++;
                        btn.setBackgroundColor(Color.RED);
                        String temp = String.valueOf(count);
                        cnt.setText(temp);
                        //등록하면 인원수 + 1
                    }
                });
        AlertDialog msgDlg = msg.create();
        msgDlg.show();
    }
}