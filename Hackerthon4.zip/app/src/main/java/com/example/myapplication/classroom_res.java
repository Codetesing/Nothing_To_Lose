package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class classroom_res extends AppCompatActivity {

    String classroom_name;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.classroom_res);


        // 버튼0 클릭 -> 강의실이동
        Button classroom_res_btn0 = (Button) findViewById(R.id.class_btn0);
        classroom_res_btn0.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Classroom_res_class0.class);
                classroom_name = classroom_res_btn0.getText().toString();
                intent.putExtra("classroom_name", classroom_name);
                startActivity(intent);
            }
        });

        // 버튼1 클릭 -> 강의실이동
        Button classroom_res_btn1 = (Button) findViewById(R.id.class_btn1);
        classroom_res_btn1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Classroom_res_class1.class);
                classroom_name = classroom_res_btn0.getText().toString();
                intent.putExtra("classroom_name", classroom_name);
                startActivity(intent);
            }
        });

        // 버튼2 클릭 -> 강의실이동
        Button classroom_res_btn2 = (Button) findViewById(R.id.class_btn2);
        classroom_res_btn2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Classroom_res_class2.class);
                classroom_name = classroom_res_btn0.getText().toString();
                intent.putExtra("classroom_name", classroom_name);
                startActivity(intent);
            }
        });

        // 버튼3 클릭 -> 강의실이동
        Button classroom_res_btn3 = (Button) findViewById(R.id.class_btn3);
        classroom_res_btn3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Classroom_res_class3.class);
                classroom_name = classroom_res_btn0.getText().toString();
                intent.putExtra("classroom_name", classroom_name);
                startActivity(intent);
            }
        });

        // 버튼4 클릭 -> 강의실이동
        Button classroom_res_btn4 = (Button) findViewById(R.id.class_btn4);
        classroom_res_btn4.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Classroom_res_class4.class);
                classroom_name = classroom_res_btn0.getText().toString();
                intent.putExtra("classroom_name", classroom_name);
                startActivity(intent);
            }
        });

        // 버튼5 클릭 -> 강의실이동
        Button classroom_res_btn = (Button) findViewById(R.id.class_btn5);
        classroom_res_btn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Classroom_res_class5.class);
                classroom_name = classroom_res_btn0.getText().toString();
                intent.putExtra("classroom_name", classroom_name);
                startActivity(intent);
            }
        });

        // 버튼6 클릭 -> 강의실이동
        Button classroom_res_btn6 = (Button) findViewById(R.id.class_btn6);
        classroom_res_btn6.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Classroom_res_class6.class);
                classroom_name = classroom_res_btn0.getText().toString();
                intent.putExtra("classroom_name", classroom_name);
                startActivity(intent);
            }
        });

    }
}
