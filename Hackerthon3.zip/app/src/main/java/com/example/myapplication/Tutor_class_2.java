package com.example.myapplication;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class Tutor_class_2 extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tutor_class_2);

        Button reg_btn = (Button) findViewById(R.id.tutor_class_2_reg_btn);
        reg_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDialog();
            }
        });
    }

    void showDialog() {
        AlertDialog.Builder msg = new AlertDialog.Builder(Tutor_class_2.this)
                .setMessage("수업 등록 하시겠습니까?")
                .setNegativeButton("예", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // 등록 완료 팝업.
                        Toast.makeText(Tutor_class_2.this, "수업 등록이 완료되었습니다.", Toast.LENGTH_SHORT).show();
                    }
                })
                .setPositiveButton("아니요", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(Tutor_class_2.this, "수업 등록이 취소되었습니다.", Toast.LENGTH_SHORT).show();
                    }
                });

        AlertDialog msgDlg = msg.create();
        msgDlg.show();
    }

}