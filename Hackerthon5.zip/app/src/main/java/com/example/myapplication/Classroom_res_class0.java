package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.material.chip.Chip;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Classroom_res_class0 extends AppCompatActivity {
    private int count;//신청한 팀 수
    private TextView cnt;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.classroom_res_class0);

        Chip classroom_res_class0_chip1 = (Chip) findViewById(R.id.time1);
        classroom_res_class0_chip1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Classroom_res_class0_table1.class);

                startActivity(intent);
            }
        });

        Chip classroom_res_class0_chip2 = (Chip) findViewById(R.id.time2);
        classroom_res_class0_chip2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Classroom_res_class0_table2.class);

                startActivity(intent);
            }
        });

        Chip classroom_res_class0_chip3 = (Chip) findViewById(R.id.time3);
        classroom_res_class0_chip3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Classroom_res_class0_table3.class);

                startActivity(intent);
            }
        });

        Chip classroom_res_class0_chip4 = (Chip) findViewById(R.id.time4);
        classroom_res_class0_chip4.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Classroom_res_class0_table4.class);

                startActivity(intent);
            }
        });
        cnt = findViewById(R.id.count);
        Intent intent = getIntent();
        String str = intent.getStringExtra("cnt");
        cnt.setText(str);;
    }
}
