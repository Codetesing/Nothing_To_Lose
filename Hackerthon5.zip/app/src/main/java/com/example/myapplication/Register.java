package com.example.myapplication;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class Register extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);

        Button btnrg = (Button) findViewById(R.id.reg_btnrg);
        btnrg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDialog();
            }
        });
    }

    void showDialog() {
        AlertDialog.Builder msg = new AlertDialog.Builder(Register.this)
                .setMessage("회원가입 하시겠습니까?")
                .setPositiveButton(Html.fromHtml("<font color='#0'>아니요</font>"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(Register.this, "회원가입이 취소되었습니다.", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                })

                .setNegativeButton(Html.fromHtml("<font color='#0'>예</font>"), (dialogInterface, i) -> {
                    // 등록 완료 팝업.
                    Toast.makeText(Register.this, "회원가입이 완료되었습니다.", Toast.LENGTH_SHORT).show();

                    finish();
                });


        AlertDialog msgDlg = msg.create();
        msgDlg.show();
    }
}