package com.parctice.registerlogin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class result extends AppCompatActivity {


    private TextView Major;
    private TextView ID;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.result);

        Major = findViewById(R.id.Major);
        ID = findViewById(R.id.ID);
        Intent intent = getIntent();
        String major = intent.getStringExtra("Major");
        String id = intent.getStringExtra("ID");

        Major.setText(major);
        ID.setText((id));
    }
}