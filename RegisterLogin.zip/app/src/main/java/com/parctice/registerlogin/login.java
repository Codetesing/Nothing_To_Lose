package com.parctice.registerlogin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class login extends AppCompatActivity {

    public String id;
    public String major;
    public EditText login_id;
    public EditText login_major;
    public Button login_btnlg;
    public Button login_btnrg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        login_id = findViewById(R.id.login_id);
        login_major = findViewById((R.id.login_major));
        login_btnlg = findViewById(R.id.login_btnlg);
        login_btnrg = findViewById(R.id.login_btnrg);
        login_btnrg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(login.this,Register.class);
            }
        });
        login_btnlg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                id = login_id.getText().toString();
                major = login_major.getText().toString();
                Intent intent = new Intent(login.this, result.class);
                intent.putExtra("ID", id);
                intent.putExtra("Major", major);
                startActivity(intent);
            }
        });
    }
}