package com.parctice.registerlogin;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class login extends AppCompatActivity {

    public String id; //id
    public String major;  //전공
    public EditText login_id;  //id from xml
    public EditText login_major;  //전공 from xml
    public Button login_btnlg; // 로그인 버튼
    public Button login_btnrg; // 회원가입 버튼

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        login_id = findViewById(R.id.login_id);
        login_major = findViewById((R.id.login_major));
        login_btnlg = findViewById(R.id.login_btnlg);
        login_btnrg = findViewById(R.id.login_btnrg);
        login_btnrg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(login.this,Register.class);
                startActivity(intent);
            }
        });
        //
        login_btnlg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                id = login_id.getText().toString();
                major = login_major.getText().toString();
                Intent intent = new Intent(login.this, result.class);
                intent.putExtra("ID", id);
                intent.putExtra("Major", major);
                startActivity(intent);
            }
        });
    }
}