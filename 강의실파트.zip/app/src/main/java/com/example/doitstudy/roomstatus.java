package com.example.doitstudy;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class roomstatus extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.classroom_res_class0_table);


        // 버튼0 클릭 -> 강의실이동
        Button classroom_res_btn0 = (Button) findViewById(R.id.class_btn0);
        classroom_res_btn0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        // 버튼1 클릭 -> 강의실이동
        Button classroom_res_btn1 = (Button) findViewById(R.id.class_btn1);
        classroom_res_btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        // 버튼2 클릭 -> 강의실이동
        Button classroom_res_btn2 = (Button) findViewById(R.id.class_btn2);
        classroom_res_btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        // 버튼3 클릭 -> 강의실이동
        Button classroom_res_btn3 = (Button) findViewById(R.id.class_btn3);
        classroom_res_btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
    }
}
