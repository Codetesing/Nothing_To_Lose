package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.google.android.material.chip.Chip;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Classroom_res_class5 extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.classroom_res_class5);

        Chip classroom_res_class5_chip1 = (Chip) findViewById(R.id.time1);
        classroom_res_class5_chip1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Classroom_res_class5_table1.class);

                startActivity(intent);
            }
        });

        Chip classroom_res_class5_chip2 = (Chip) findViewById(R.id.time2);
        classroom_res_class5_chip2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Classroom_res_class5_table2.class);

                startActivity(intent);
            }
        });

        Chip classroom_res_class5_chip3 = (Chip) findViewById(R.id.time3);
        classroom_res_class5_chip3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Classroom_res_class5_table3.class);

                startActivity(intent);
            }
        });

        Chip classroom_res_class5_chip4 = (Chip) findViewById(R.id.time4);
        classroom_res_class5_chip4.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Classroom_res_class5_table4.class);

                startActivity(intent);
            }
        });

    }
}
