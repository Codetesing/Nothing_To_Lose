package com.example.myapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.chip.Chip;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Classroom_res_class0 extends AppCompatActivity {
    private TextView cnt;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.classroom_res_class0);

        cnt = findViewById(R.id.count);

        Chip classroom_res_class0_chip1 = (Chip) findViewById(R.id.time1);
        classroom_res_class0_chip1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Classroom_res_class0_table1.class);
                //String temp = cnt.getText().toString();
                //intent.putExtra("cnt", temp);
                startActivityForResult(intent, 0);
            }
        });

        Chip classroom_res_class0_chip2 = (Chip) findViewById(R.id.time2);
        classroom_res_class0_chip2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Classroom_res_class0_table2.class);

                startActivity(intent);
            }
        });

        Chip classroom_res_class0_chip3 = (Chip) findViewById(R.id.time3);
        classroom_res_class0_chip3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Classroom_res_class0_table3.class);

                startActivity(intent);
            }
        });

        Chip classroom_res_class0_chip4 = (Chip) findViewById(R.id.time4);
        classroom_res_class0_chip4.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Classroom_res_class0_table4.class);

                startActivity(intent);
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){//classtable에서 보내는 intent받기
        super.onActivityResult(requestCode, resultCode, data);
        Toast.makeText(this, "왜않함?", Toast.LENGTH_SHORT).show();
        if(resultCode == RESULT_OK) {
            String str = data.getStringExtra("cnt");
            cnt.setText(str);
        }
    }


}
